const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const source=fs.readFileSync(require('node:path').join(__dirname,'../app.js'),'utf8');
function boot(){
 const elements=new Map();
 function el(id){if(id==='.hero-carousel')return null;if(!elements.has(id))elements.set(id,{dataset:{},innerHTML:'',textContent:'',value:id==='#tuning'?'80':'60',style:{setProperty(){}},classList:{add(){},toggle(){}},setAttribute(){},removeAttribute(){},focus(){},querySelectorAll(s){return s==='[data-answer]'?buttons:[];}});return elements.get(id);}
 const buttons=Array.from({length:4},(_,i)=>({dataset:{answer:String(i)},disabled:false,classList:{add(){}}}));
 const context=vm.createContext({document:{querySelector:el,querySelectorAll:()=>[],title:''},location:{hash:''},window:{addEventListener(){},scrollTo(){}},localStorage:{getItem(){return null;},setItem(){}}});
 vm.runInContext(source,context);
 return {run:s=>vm.runInContext(s,context),el,buttons};
}
test('cinco telas renderizam conteúdo e equipe completa',()=>{const b=boot();for(const route of ['inicio','como-funciona','simulador','historia','quiz']){b.run(`location.hash='#${route}';navigate()`);assert.match(b.el('main').innerHTML,/<h1>/);}b.run("location.hash='#inicio';navigate()");for(const ra of ['Caio Leo','Danilo Alves','Flávio Diogo','Gustavo Pestana','Luiz Gustavo'])assert.ok(b.el('main').innerHTML.includes(ra));});
test('quiz completo: pontuação, bloqueio de duplo clique, resultado e reinício',()=>{const b=boot();b.run("location.hash='#quiz';navigate()");for(let i=0;i<6;i++){const c=b.run(`questions[${i}].c`);b.buttons[c].onclick();b.buttons[c].onclick();assert.equal(b.run('answers.length'),i+1);b.el('#next').onclick();}assert.match(b.el('#quiz-content').innerHTML,/600.*600 pontos/);assert.equal(b.run('quizIndex'),6);b.el('#restart').onclick();assert.equal(b.run('answers.length'),0);assert.equal(b.run('quizIndex'),0);});
test('quiz com erros fornece resultado zero e revisão',()=>{const b=boot();b.run("location.hash='#quiz';navigate()");for(let i=0;i<6;i++){b.buttons[(b.run(`questions[${i}].c`)+1)%4].onclick();b.el('#next').onclick();}assert.match(b.el('#quiz-content').innerHTML,/Você acertou 0 de 6/);assert.match(b.el('#quiz-content').innerHTML,/Resposta correta/);});
test('simulador responde à sintonia, pausa e restauração',()=>{const b=boot();b.run("location.hash='#simulador';navigate()");assert.equal(b.el('#response').textContent,'0%');b.el('#toggle').onclick();const detuned=parseInt(b.el('#response').textContent);b.el('#tuning').value='100';b.el('#tuning').oninput();assert.equal(b.el('#response').textContent,'60%');assert.ok(detuned<60);b.el('#toggle').onclick();assert.equal(b.el('#response').textContent,'0%');b.el('#reset-sim').onclick();assert.equal(b.el('#tuning').value,80);assert.equal(b.run('running'),false);});
test('rota inválida retorna ao início',()=>{const b=boot();b.run("location.hash='#inexistente';navigate()");assert.match(b.el('main').innerHTML,/Conheça a equipe/);});


test('quiz mantém resposta ao navegar para outra tela e voltar',()=>{const b=boot();b.run("location.hash='#quiz';navigate()");b.buttons[1].onclick();b.run("location.hash='#inicio';navigate();location.hash='#quiz';navigate()");assert.equal(b.run('answers.length'),1);assert.equal(b.el('#next').disabled,false);b.el('#next').onclick();assert.equal(b.run('quizIndex'),1);});
