# Bobina de Tesla · Entrega para Windows Server 2022

## O que este ZIP entrega

Aplicação completa com fotografias, carrossel, simulador, quiz e processo criativo. O servidor em JavaScript verifica Windows Server 2022 (build 20348, ProductType de servidor) por CIM antes de escutar conexões. O provisionamento associa a configuração ao nome do computador. O navegador obtém uma sessão do servidor, carrega a aplicação e confirma a conexão a cada cinco segundos. Sem resposta, a interface é encerrada após o tempo de detecção e uma nova conexão é necessária. Não existe modo offline nesta edição.

O bloqueio atende à execução normal do pacote. Não é DRM: o código é editável, o nome de máquina pode ser replicado e um administrador com acesso aos fontes pode modificar verificações ou copiar o conteúdo. Uma página web executa parte do código no navegador dos visitantes; quem hospeda e valida esta edição é a VM Windows Server. O teste de sistema operacional é feito no servidor, nunca no computador visitante.

Os arquivos antigos na raiz do projeto e o site Netlify continuam sendo versões independentes. Este ZIP não despublica sites, não muda o roteador e não configura outras máquinas automaticamente. Para demonstrar a exclusividade do servidor, use somente o endereço da VM e retire de circulação as versões antigas. Se quiser apagar/desativar hospedagens antigas, faça isso no painel correspondente após confirmar a migração.

## Instalação dentro da VM

1. Prepare uma VM Windows Server 2022 com rede e atualizações. Defina o nome definitivo da VM antes de provisionar.
2. Instale Node.js de uma versão suportada pelo Windows Server 2022 a partir de https://nodejs.org/ . O runtime não está incluído no ZIP. Não há pacotes npm a instalar. Para um laboratório sem internet, obtenha previamente o instalador oficial e transfira-o à VM.
3. Extraia o ZIP, por exemplo em `C:\ExpoTech`. Mantenha o pacote fora de pastas publicadas pelo IIS e não configure outro servidor estático para a subpasta public.
4. No PowerShell, na pasta extraída, execute ` .\scripts\Preparar.ps1 ` e depois ` .\scripts\Iniciar.ps1 `. Se a política de execução bloquear scripts, siga a política institucional de assinatura/aprovação; não é necessário desativá-la. O comando `node .\server.cjs` também inicia o servidor após o provisionamento.
5. Mantenha esse processo aberto. Ele mostra os endereços da VM; no próprio servidor abra `http://localhost:8080`.
6. Como administrador, libere somente a sub-rede real do laboratório/VPN: ` .\scripts\Firewall.ps1 -RedePermitida '192.168.10.0/24' `. O endereço é exemplo: substitua pela sua rede. A regra permite TCP 8080 nos perfis Privado e Domínio. O script não altera o perfil da rede e não desativa o firewall.
7. De um cliente na rede autorizada, abra `http://IP-DA-VM:8080`. Use o endereço da VM, não o IP do host Hyper-V.
8. Para encerrar, Ctrl+C. Reinicie o processo para voltar a servir a aplicação. Esta entrega usa execução interativa; não instala um serviço persistente nem tarefa agendada.

O HTTP desta configuração destina-se ao laboratório/rede privada ou acesso através da VPN. Para publicar diretamente na internet, configure HTTPS com certificado confiável em um proxy reverso e preserve as verificações do servidor. Não publique RDP, SMB nem o servidor de laboratório diretamente no roteador como parte desta instalação.

## Teste de aceitação

- Na VM: executar `node server.cjs`, abrir as seis telas e carregar as fotografias.
- Em Windows 10/11: executar o mesmo servidor; deve encerrar com mensagem de bloqueio e código 1 antes de abrir a porta.
- Via arquivo local ou hospedagem estática: a interface não deve inicializar, pois a API de sessão não existe.
- Com a aplicação aberta no cliente: desligar o processo Node na VM e aguardar aproximadamente 5–10 segundos em uma aba ativa; a interface deve encerrar. Abas suspensas dependem do agendamento do navegador; ao voltar, há nova verificação.
- Reiniciar o servidor e atualizar a página: aplicação disponível novamente.
- Na VM ou cliente com Python instalado: `python scripts/verificar.py http://IP-DA-VM:8080`. Salve a saída como evidência. O script testa sessão, bloqueio de app sem sessão e proteção de configuração/scripts.

## Arquitetura para apresentação

PC físico/casemod → Windows 10 Pro + Linux em dual boot → Hyper-V no Windows → VM Windows Server 2022 → Node.js + aplicação → clientes do laboratório/VPN.

No dual boot somente um sistema do host roda por vez. A VM Hyper-V ficará disponível enquanto o Windows host estiver ligado e executando-a; iniciar o Linux do dual boot interrompe esse ambiente. Planeje a demonstração nessa ordem.

O serviço web é a proposta de serviço da casa/laboratório: um portal educativo acessível por outros dispositivos. Confirme com o professor se esse portal satisfaz o sentido de “serviço da casa” na avaliação.

Consulte `docs/REQUISITOS-E-EVIDENCIAS.md` e `docs/RELATORIO-SEGURANCA.md`. A aplicação não comprova automaticamente os requisitos físicos e de infraestrutura.
