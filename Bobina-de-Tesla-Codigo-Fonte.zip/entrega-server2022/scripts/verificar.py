"""Automação de verificação HTTP. Execute: python scripts/verificar.py http://IP-DA-VM:8080"""
import sys,json,urllib.request,urllib.error,datetime
base=sys.argv[1].rstrip('/') if len(sys.argv)>1 else 'http://localhost:8080'
def check(route,expected,headers=None):
    try:
        with urllib.request.urlopen(urllib.request.Request(base+route,headers=headers or {}),timeout=8) as response:
            status=response.status; body=response.read()
    except urllib.error.HTTPError as error:
        status=error.code; body=error.read()
    if status!=expected: raise RuntimeError(f'{route}: esperado {expected}, recebido {status}')
    print(f'OK {route}: {status}')
    return body
check('/',200)
session=json.loads(check('/api/session',200))
check('/app.js',403)
check('/app.js?session='+session['token'],200)
check('/api/heartbeat',200,{'X-Tesla-Session':session['token']})
check('/api/heartbeat',401)
check('/server-config.json',404)
check('/scripts/Preparar.ps1',404)
print('Verificação concluída em',datetime.datetime.now().isoformat())
