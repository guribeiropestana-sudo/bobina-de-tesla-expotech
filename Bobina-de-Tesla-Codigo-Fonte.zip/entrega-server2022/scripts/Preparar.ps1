param([ValidateRange(1024,65535)][int]$Port=8080)
$ErrorActionPreference='Stop'
$info=Get-CimInstance Win32_OperatingSystem
if($info.Caption -notmatch 'Windows Server 2022' -or $info.BuildNumber -ne '20348' -or $info.ProductType -eq 1){throw 'Execute dentro do Windows Server 2022.'}
$projectRoot=Split-Path -Parent $PSScriptRoot
$nodeCommand=Get-Command node -ErrorAction Stop
& $nodeCommand.Source --version
if($LASTEXITCODE -ne 0){throw 'Node.js indisponível.'}
@{hostname=$env:COMPUTERNAME;port=$Port} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $projectRoot 'server-config.json') -Encoding UTF8
# Windows PowerShell 5.1 emits a BOM; rewrite configuration as UTF-8 without BOM.
$configPath=Join-Path $projectRoot 'server-config.json'
[IO.File]::WriteAllText($configPath,(Get-Content -LiteralPath $configPath -Raw),(New-Object Text.UTF8Encoding($false)))
Write-Host 'Servidor provisionado. Execute scripts/Iniciar.ps1.'
