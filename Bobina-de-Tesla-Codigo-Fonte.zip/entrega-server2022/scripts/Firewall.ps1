param([Parameter(Mandatory=$true)][string]$RedePermitida,[ValidateRange(1024,65535)][int]$Port=8080)
$ErrorActionPreference='Stop'
# Execute as administrator in the VM. Supply the actual lab/VPN subnet, e.g. 192.168.10.0/24.
if(Get-NetFirewallRule -Name 'ExpoTech-Web' -ErrorAction SilentlyContinue){throw 'A regra ExpoTech-Web já existe. Revise-a antes de alterar.'}
New-NetFirewallRule -Name 'ExpoTech-Web' -DisplayName 'ExpoTech - aplicação web' -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -RemoteAddress $RedePermitida -Profile Domain,Private
