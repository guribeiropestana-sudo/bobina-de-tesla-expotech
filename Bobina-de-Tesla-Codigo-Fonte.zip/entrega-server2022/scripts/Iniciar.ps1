$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
& node (Join-Path $projectRoot 'server.cjs')
if($LASTEXITCODE -ne 0){throw 'Servidor não iniciou. Confira a mensagem acima.'}
