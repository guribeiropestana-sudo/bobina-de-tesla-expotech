# Matriz de requisitos do trabalho

Status inicial: infraestrutura não verificada. Preencha com evidências reais; esta matriz não constitui aprovação de nenhum item.

| Área do print | Entrega ou preparação | Evidência necessária na apresentação |
|---|---|---|
| CASEMOD: estrutura física funcional | Fotos existentes documentam componentes de computador e BIOS | Fotos atuais do casemod completo, identificação dos componentes e demonstração funcional |
| BIOS e boot | Conteúdo fotográfico na aplicação | Vídeo ou capturas da BIOS e sequência real de inicialização |
| Windows 10 Pro | Requisito do host, não instalado por este ZIP | Captura da edição/licença e configuração do host |
| Dual boot com Linux | Deve ser instalado pelo grupo | Menu de boot e inicialização comprovada de ambos os sistemas |
| Partição SSD para VMs/Hyper-V | Planejar armazenamento separado e Hyper-V no host | Gerenciamento de Disco, capacidade, caminhos dos discos virtuais e Gerenciador Hyper-V |
| VM Windows Server 2019+ | Pacote exige especificamente Server 2022 | Configuração da VM, versão do Windows e processo Node ativo |
| Serviço da casa | Portal educativo proposto para a rede | Aprovação da finalidade pelo professor e acesso a partir de outro dispositivo |
| Rede: patch cord | Atividade física do laboratório | Foto do cabo, identificação/pinagem e teste com testador quando disponível |
| Conectividade host–VM | Usar switch virtual e endereçamento compatível com o laboratório | IP/máscara/gateway, diagrama, teste HTTP host→VM; ping depende de regra ICMP |
| RDP/SSH | Configurar RDP administrativo com NLA ou SSH conforme orientação | Sessão remota autorizada e registro da política/regras, sem divulgar credenciais |
| Firewall | Script de regra TCP 8080 com escopo de origem | Regra aplicada e testes de acesso permitido/bloqueado de origens distintas |
| DNS seguro | Definir resolução, DNS confiável e controle de alterações | Nome do portal resolvido, configuração do resolvedor e evidência da proteção escolhida; um registro DNS sozinho não comprova segurança |
| VPN | Configurar no ambiente do grupo | Cliente externo conectado e acesso ao IP/nome privado da VM via túnel |
| Kali Linux ou Parrot OS | VM de auditoria separada | Tela da distribuição e rede de laboratório autorizada |
| Nmap/OpenVAS | Auditoria somente nos alvos autorizados | Escopo, versão da ferramenta, saídas reais, interpretação e reteste |
| Relatório de segurança | Modelo incluído | Relatório preenchido com evidências reais e correções |
| Automação Python/Java | `scripts/verificar.py`, Python sem bibliotecas externas | Execução do script e saída datada no servidor/cliente |
| Git/GitHub | Versionar o pacote e documentação | Repositório do grupo, histórico de commits e link do GitHub; nenhum push é feito por esta entrega |

## Sequência sugerida de implantação

1. Inventariar hardware, SSD, memória e suporte à virtualização; registrar BIOS e casemod.
2. Planejar e fazer backup antes de preparar partições e dual boot. Não há automação de reparticionamento neste pacote.
3. Ativar Hyper-V no Windows 10 Pro e criar VM com Windows Server 2022. Ajustar CPU/RAM/disco aos recursos reais disponíveis.
4. Definir switch virtual, IP estável e resolução DNS; confirmar comunicação host–VM.
5. Instalar o runtime, provisionar o portal e aplicar regra de firewall com a rede correta.
6. Configurar acesso administrativo e VPN com a orientação do laboratório; registrar escopo e usuários.
7. Demonstrar o portal e o bloqueio ao parar o servidor; executar a automação Python.
8. Fazer auditoria do alvo autorizado e preencher o relatório; corrigir e repetir os testes necessários.
9. Versionar fontes e documentação no Git/GitHub. Evitar configurações privadas, credenciais, discos de VM e saídas com dados sensíveis em repositório público.

## Referências oficiais

- Hyper-V: https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/get-started/install-hyper-v
- Requisitos de hardware: https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/host-hardware-requirements
- RDP: https://learn.microsoft.com/windows-server/remote/remote-desktop-services/remotepc/remote-desktop-allow-access
- Windows Server 2022: https://learn.microsoft.com/en-us/windows-server/get-started/whats-new-in-windows-server-2022
