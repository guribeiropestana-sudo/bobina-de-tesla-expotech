# Relatório de segurança — preencher após os testes

Situação: modelo, nenhuma auditoria executada por esta entrega.

## Identificação e autorização

- Equipe e responsável pela autorização:
- Data, horário e rede do laboratório:
- IP/nome da VM autorizada e serviços incluídos:
- IP da máquina Kali/Parrot:
- Ativos excluídos do teste:

## Ambiente

Registrar versões do Windows, Node.js, aplicação, ferramentas e configurações de DNS, VPN, acesso remoto e firewall. Anexar diagrama e evidências sem senhas ou tokens.

## Procedimento e resultados

1. Registrar resolução DNS e conectividade pelo caminho autorizado.
2. Inventariar portas do alvo autorizado com Nmap e comparar com as regras planejadas. Informar o comando realmente utilizado e anexar a saída.
3. Se exigido pelo professor, executar a avaliação de vulnerabilidades com OpenVAS/Greenbone no mesmo escopo. Documentar possíveis efeitos e realizar em janela autorizada.
4. Executar `scripts/verificar.py` e o teste de indisponibilidade ao parar o servidor.
5. Revisar resultados; diferenciar portas abertas esperadas, falsos positivos e vulnerabilidades confirmadas.

| ID | Evidência/achado | Impacto | Correção proposta | Responsável | Reteste/data |
|---|---|---|---|---|---|
| A preencher | | | | | |

## Limites e conclusão

Documentar o que não foi testado e problemas ainda abertos. Não declarar “sem vulnerabilidades” com base somente em uma varredura. As verificações de sistema operacional da aplicação controlam sua implantação normal e não impedem alteração dos fontes por um administrador.
