'use strict';
(async()=>{
 let timer=null;
 function unavailable(){
  if(timer)clearInterval(timer);
  // Reloading removes all application event handlers and timers as well as the UI.
  if(location.hash!=='#servidor-indisponivel'){location.replace(location.pathname+'#servidor-indisponivel');location.reload();return;}
  document.querySelector('main').textContent='Servidor indisponível. Para utilizar a aplicação, inicie o serviço no Windows Server 2022 e atualize esta página.';
 }
 try{
  if(!/^https?:$/.test(location.protocol))throw Error('Abra pelo servidor.');
  const response=await fetch('/api/session',{cache:'no-store',signal:AbortSignal.timeout(5000)});
  if(!response.ok)throw Error('Sem sessão');const session=await response.json();
  if(session.server!=='Windows Server 2022'||!/^[a-f0-9]{64}$/.test(session.token))throw Error('Resposta inválida');
  const script=document.createElement('script');script.src='/app.js?session='+session.token;
  script.onerror=unavailable;document.head.append(script);
  let checking=false;
  async function heartbeat(){if(checking)return;checking=true;try{const r=await fetch('/api/heartbeat',{cache:'no-store',headers:{'X-Tesla-Session':session.token},signal:AbortSignal.timeout(5000)});if(!r.ok)throw Error('Sem servidor');}catch{unavailable();}finally{checking=false;}}
  timer=setInterval(heartbeat,5000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)heartbeat();});
 }catch{unavailable();}
})();
