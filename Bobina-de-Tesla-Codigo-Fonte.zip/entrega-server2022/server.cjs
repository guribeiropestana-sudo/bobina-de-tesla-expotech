'use strict';
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
function validatePlatform(){
 if(process.platform!=='win32')throw Error('Este pacote exige Windows Server 2022.');
 const info=JSON.parse(execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-Command','Get-CimInstance Win32_OperatingSystem | Select-Object Caption,BuildNumber,ProductType | ConvertTo-Json -Compress'],{encoding:'utf8',windowsHide:true,timeout:15000}));
 if(!/Windows Server 2022/i.test(info.Caption)||String(info.BuildNumber)!=='20348'||Number(info.ProductType)===1)throw Error('Sistema não autorizado: exige Windows Server 2022, build 20348.');
 return info;
}
function start(){
 const platform=validatePlatform();
 const config=JSON.parse(fs.readFileSync(path.join(__dirname,'server-config.json'),'utf8'));
 if(config.hostname!==os.hostname())throw Error('O pacote deve ser provisionado neste servidor com scripts/Preparar.ps1.');
 const port=Number(config.port);if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Porta inválida.');
 const root=path.join(__dirname,'public');
 const tokens=new Map();
 const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg'};
 const server=http.createServer((req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end();}
  let url;try{url=new URL(req.url,'http://localhost');}catch{res.writeHead(400);return res.end();}
  if(url.pathname==='/api/session'){
   const now=Date.now();for(const [key,expiry] of tokens)if(expiry<now)tokens.delete(key);
   if(tokens.size>=1000){res.writeHead(503);return res.end();}
   const token=crypto.randomBytes(32).toString('hex');tokens.set(token,now+30000);
   res.setHeader('Content-Type','application/json');return res.end(JSON.stringify({token,server:'Windows Server 2022'}));
  }
  if(url.pathname==='/api/heartbeat'){
   const token=req.headers['x-tesla-session'];if(!tokens.has(token)||tokens.get(token)<Date.now()){res.writeHead(401);return res.end();}
   tokens.set(token,Date.now()+30000);res.setHeader('Content-Type','application/json');return res.end('{"active":true}');
  }
  if(url.pathname==='/app.js'&&(!tokens.has(url.searchParams.get('session'))||tokens.get(url.searchParams.get('session'))<Date.now())){res.writeHead(403);return res.end();}
  let name;try{name=decodeURIComponent(url.pathname).slice(1)||'index.html';}catch{res.writeHead(400);return res.end();}
  // Allow only application files; configuration and scripts are never served.
  if(!['index.html','styles.css','bootstrap.js','app.js'].includes(name)&&!/^assets\/[a-zA-Z0-9_-]+\.(jpg|jpeg)$/.test(name)){res.writeHead(404);return res.end();}
  fs.readFile(path.join(root,name),(err,data)=>{if(err){res.writeHead(404);return res.end();}res.setHeader('Content-Type',types[path.extname(name)]);res.end(req.method==='HEAD'?undefined:data);});
 });
 server.on('error',error=>{console.error(error.message);process.exitCode=1;});
 server.listen(port,'0.0.0.0',()=>{
  console.log(`${platform.Caption} · ${os.hostname()} · porta ${port}`);
  console.log(`Acesso local: http://localhost:${port}`);
  for(const net of Object.values(os.networkInterfaces()).flat())if(net.family==='IPv4'&&!net.internal)console.log(`Rede: http://${net.address}:${port}`);
 });
 return server;
}
if(require.main===module){try{start();}catch(error){console.error('Inicialização bloqueada: '+error.message);process.exitCode=1;}}
module.exports={validatePlatform,start};
