// Servidor local sem dependências. Execute: node server.js
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const root = __dirname;
const allowed = new Set(['index.html','styles.css','app.js','assets/tesla-coil.jpg','assets/tesla-contemporanea.jpg','assets/tesla-bipolar.jpg','assets/processo-01-componentes.jpeg','assets/processo-02-ventilacao.jpeg','assets/processo-03-inicializacao.jpeg','assets/processo-04-bancada.jpeg']);
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg'};
http.createServer((req,res)=>{
 let pathname;try{pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname).replace(/^\//,'')||'index.html';}catch{res.writeHead(400);return res.end('Requisição inválida');}
 if(!allowed.has(pathname)){res.writeHead(404);return res.end('Não encontrado');}
 fs.readFile(path.join(root,pathname),(err,data)=>{if(err){res.writeHead(404);return res.end('Não encontrado');}res.writeHead(200,{'Content-Type':types[path.extname(pathname)],'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(data);});
}).on('error',error=>{
 console.error(error.code==='EADDRINUSE'?'A porta 8080 já está em uso. Encerre o servidor anterior com Ctrl+C e tente novamente.':`Não foi possível iniciar o servidor: ${error.message}`);
 process.exitCode=1;
}).listen(8080,'0.0.0.0',()=>{
 console.log('Bobina de Tesla · ExpoTech · Servidor disponível na rede local');
 console.log('Neste computador: http://127.0.0.1:8080');
 const addresses=new Set(Object.values(os.networkInterfaces()).flat().filter(address=>address && address.family==='IPv4' && !address.internal).map(address=>address.address));
 for(const address of addresses)console.log(`Em outros dispositivos na mesma rede: http://${address}:8080`);
 if(!addresses.size)console.log('Nenhum endereço IPv4 de rede encontrado. Conecte o computador ao Wi-Fi ou à rede cabeada e reinicie o servidor.');
 console.log('Mantenha este computador e o terminal ligados. Ctrl+C para encerrar.');
});
