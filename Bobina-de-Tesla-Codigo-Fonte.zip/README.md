# Bobina de Tesla · ExpoTech

**Demonstração offline:** faça o download de `Bobina-de-Tesla-Offline.html` e abra no navegador. Para instalar na VM, siga `entrega-server2022/LEIA-ME.md`.

Aplicação educativa em HTML, CSS e JavaScript puro. Sem React, pacotes, compilação, CDN, contas ou conexão com hardware.

## Executar no VS Code

1. Abra esta pasta em **Arquivo → Abrir Pasta**.
2. Abra **Terminal → Novo Terminal**.
3. Com Node.js instalado, execute `node server.js`.
4. Acesse http://127.0.0.1:8080 no navegador. Para encerrar, use Ctrl+C no terminal.

Alternativa: use **Open with Live Server** na extensão Live Server do VS Code. Também é possível abrir `index.html` diretamente por duplo clique: o projeto não usa módulos ou requisições de conteúdo e funciona via `file://`.

## Acessar de outros computadores e celulares

1. Conecte o computador que guarda o projeto e os demais dispositivos à mesma rede Wi-Fi ou rede cabeada.
2. No computador do projeto, execute `node server.js`. Se já estiver rodando uma versão anterior, encerre com Ctrl+C e inicie novamente.
3. O terminal mostrará **Em outros dispositivos na mesma rede: http://SEU-IP:8080**. Abra esse endereço no navegador das outras máquinas. Não use `localhost` ou `127.0.0.1` nelas, pois esses endereços apontam para o próprio dispositivo.
4. Mantenha o computador do projeto ligado, sem suspensão, e o terminal aberto durante a apresentação.

O servidor aceita conexões pelas interfaces de rede do computador e disponibiliza somente os arquivos da aplicação listados em `server.js`. Cada visitante usa seu próprio quiz; não existe um placar compartilhado.

Se o Windows solicitar permissão para Node.js, permita o acesso em **redes privadas** quando estiver usando uma rede confiável. Não é necessário desativar o firewall. Caso o acesso seja bloqueado, confira a permissão do Node.js no Firewall do Windows e se o endereço digitado corresponde ao Wi-Fi ou Ethernet em uso. Redes de convidados e algumas redes da faculdade isolam os dispositivos; nesse caso, use uma rede que permita comunicação entre eles ou um ponto de acesso próprio.

É possível ter vários endereços no terminal, por exemplo por causa de VPNs e adaptadores virtuais. Escolha o endereço da rede compartilhada com os visitantes. Ele pode mudar ao reconectar o computador; confira o terminal ao iniciar a apresentação.

Essa forma de acesso funciona na rede local, mesmo sem internet. Para acesso de qualquer lugar por um link público, é necessário hospedar a aplicação na internet; isso não é feito por este servidor local.

Todos os recursos da aplicação ficam na pasta: funciona sem internet, inclusive pelo servidor local. Somente os links opcionais das fontes precisam de internet. Não há service worker: mantenha os arquivos no computador da apresentação.

## Arquivos editáveis

- `index.html`: estrutura principal e navegação.
- `styles.css`: visual, cores e responsividade; variáveis de cor no início.
- `app.js`: conteúdo das cinco telas, equipe, seis etapas, histórico, modelo e quiz.
- `assets/tesla-coil.jpg`: fotografia histórica real; pode ser substituída por foto da bobina do grupo, atualizando também legenda, texto alternativo e crédito em `app.js`.
- `server.js`: servidor de desenvolvimento local, sem dependências.
- `tests/smoke.cjs`: verificação das regras do quiz e do simulador com ambiente DOM simplificado; execute `node --test tests/smoke.cjs`.

## Comportamento

A navegação usa fragmentos de URL, permitindo atualizar a página ou compartilhar uma tela local específica. O quiz tem seis questões, bloqueia respostas repetidas, explica cada resposta e oferece revisão e reinício. A melhor pontuação é salva somente neste navegador quando o armazenamento local está disponível. Não são coletados dados de visitantes.

O simulador usa uma curva de resposta de oscilador amortecido com Q fixo em 8. A frequência é relativa a f₀ e a excitação é adimensional. É uma analogia educativa de ressonância, não uma simulação quantitativa dos circuitos acoplados. Os controles não representam ajustes de montagem ou operação de um equipamento real. O desenho do simulador é um diagrama; a imagem inicial é uma fotografia histórica.

A bobina real fica fisicamente separada. A aplicação não mede nem controla equipamentos e não determina condições de segurança para a demonstração física.

## Fontes e imagem

- Museu Nikola Tesla: https://tesla-museum.org/en/qr-en/exhibit-010/
- Departamento de Energia dos EUA: https://www.energy.gov/articles/war-currents-ac-vs-dc-power
- EIA: https://www.eia.gov/kids/history-of-energy/famous-people/tesla.php
- Fotografia: https://commons.wikimedia.org/wiki/File:Tesla_lab_coil1.jpg — Tonnele and Co., publicada em abril de 1895 na Century Magazine. Domínio público nos EUA conforme a página do arquivo. A exposição prolongada acentua o aspecto das descargas. A foto é histórica e não representa a bobina da equipe.

O visual segue a descrição aprovada de fundo escuro, azul elétrico e roxo. Os arquivos visuais do mockup anterior não estavam disponíveis no histórico recuperado.


## Galeria da página inicial

O carrossel contém três fotografias reais armazenadas em `assets/`. Avança a cada sete segundos, com setas, indicadores, gesto lateral no celular e controle de pausa. A rotação pausa durante foco do teclado, passagem do mouse ou ocultação da aba. Com preferência por movimento reduzido, inicia pausado. O temporizador é encerrado ao trocar de tela.

Créditos adicionais: Vanadict, *Tesla coil from scrap*, CC0 1.0 — https://commons.wikimedia.org/wiki/File:Tesla_coil_from_scrap.jpg ; Harry La Verne Twining, *Bipolar Tesla transformer 1908*, domínio público nos EUA — https://commons.wikimedia.org/wiki/File:Bipolar_Tesla_transformer_1908.jpg . As fotografias do carrossel são referências e não retratam o equipamento da equipe.
